package com.mojang.minecraft.level.levelgen;

import com.mojang.minecraft.Minecraft;
import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.level.LevelLoaderListener;
import com.mojang.minecraft.level.levelgen.synth.PerlinNoise;
import com.mojang.minecraft.level.tile.Tile;
import java.util.ArrayList;
import java.util.Random;

public class LevelGen {
    private LevelLoaderListener levelLoaderListener;
    private Minecraft minecraft;
    private int width;
    private int height;
    private int depth;
    private final boolean islandMode = false;
    private Random random = new Random();
    private byte[] blocks;
    private int[] coords = new int[1048576];

    public LevelGen(LevelLoaderListener levelLoaderListener) {
        this.levelLoaderListener = levelLoaderListener;
    }

    public boolean generateLevel(Level level, String userName, int width, int height, int depth) {
        this.levelLoaderListener.beginLevelLoading("Generating level");
        this.width = width;
        this.height = height;
        this.depth = depth;
        this.blocks = new byte[width * height * depth];
        this.levelLoaderListener.levelLoadUpdate("Raising..");
        double[] heightMap = this.buildHeightmap(width, height);
        this.levelLoaderListener.levelLoadUpdate("Eroding..");
        this.buildBlocks(heightMap);
        this.levelLoaderListener.levelLoadUpdate("Carving..");
        this.carveTunnels(this.blocks);
        this.levelLoaderListener.levelLoadUpdate("Watering..");
        this.addWater();
        this.levelLoaderListener.levelLoadUpdate("Melting..");
        this.addLava();
        level.setData(width, depth, height, this.blocks);
        level.createTime = System.currentTimeMillis();
        level.creator = userName;
        level.name = "A Nice World";
        return true;
    }

    public byte[] buildBlocks(double[] heightMap) {
        int w = width;
        int h = height;
        int d = depth;
        int[] heightmap1 = new PerlinNoise(random, 0, islandMode).read(w, h);
        int[] heightmap2 = new PerlinNoise(random, 1, islandMode).read(w, h);
        int[] cf = new PerlinNoise(random, 3, false).read(w, h);
        int[] cf2 = new PerlinNoise(random, 3, false).read(w, h);
        int[] rockMap = new PerlinNoise(random, 1, islandMode).read(w, h);

        int waterLevel = d / 2;

        for (int x = 0; x < w; x++) {
            this.loading(x * 100 / (w - 1));
            for (int y = 0; y < d; y++) {
                for (int z = 0; z < h; z++) {
                    int dh1 = heightmap1[x + z * width];
                    int dh2 = heightmap2[x + z * width];
                    int cfh = cf[x + z * width];
                    int cfh2 = cf2[x + z * width];

                    if (cfh < 128) {
                        dh2 = dh1;
                    }

                    int dh = dh1;
                    if (dh2 > dh) {
                        dh = dh2;
                    }else {
                        dh2 = dh1;
                    }
                    dh = (dh - 128) / 8;
                    dh = dh + waterLevel - 3;

                    //                    dh = dh+d/2-4;
                    //                    dh = (dh / 2 + (d / 2-4))/2;

                    //                    dh -= hh;

                    int rh = ((rockMap[x + z * width] - 128) / 6 + waterLevel + dh) / 2;
                    if (cfh2 < 50) {
                        dh = (dh / 4 * 4)-3;
                    }else if (cfh2 < 132) {
                        dh = (dh / 2 * 2)-1;
                    }
                    int ww = waterLevel-2;
                    if (dh < ww) {
                        dh = (dh - ww) / 2 + ww;
                    }

                    if (rh > dh - 2) {
                        rh = dh - 2;
                    }
                    //                    rh = (dh1+dh2*4)/5/16+d/2-2;
                                        rh = dh-2;
                    int i = (y * height + z) * width + x;
                    int id = 0;
                    if (y == dh && y >= d / 2-1) {
                        id = Tile.grass.id;
                    }else if (y <= dh) {
                        id = Tile.dirt.id;
                    }
                    if (y <= rh) {
                        id = Tile.rock.id;
                    }
                    //                    if (id==0 && y<d/2 && (x==0 || z==0 || x==w-1 || z==h-1))
                    //                    {
                    //                        id = Tile.water.id;
                    //                    }
                    blocks[i] = (byte) id;
                }
            }
        }
        return blocks;
    }

    private double[] buildHeightmap(int width, int height) {
        double[] heightmap = new double[width * height];
        return heightmap;
    }

    public byte[] carveTunnels(byte[] blocks) {
        int w = width;
        int h = height;
        int d = depth;

        int count = w * h * d / 256 / 64;
        for (int i = 0; i < count; i++) {
            this.loading(i * 100 / (count - 1));
            float x = random.nextFloat() * w;
            float y = random.nextFloat() * d;
            float z = random.nextFloat() * h;
            int length = (int) (random.nextFloat() + random.nextFloat() * 150);
            float dir1 = (float) (random.nextFloat() * Math.PI * 2);
            float dira1 = 0;
            float dir2 = (float) (random.nextFloat() * Math.PI * 2);
            float dira2 = 0;

            for (int l = 0; l < length; l++) {
                x += Math.sin(dir1) * Math.cos(dir2);
                z += Math.cos(dir1) * Math.cos(dir2);
                y += Math.sin(dir2);

                dir1 += dira1 * 0.2f;
                dira1 *= 0.9f;
                dira1 += (random.nextFloat() - random.nextFloat());

                dir2 += dira2 * 0.5f;
                dir2 *= 0.5f;
                dira2 *= 0.9f;
                dira2 += (random.nextFloat() - random.nextFloat());

                float size = (float) (Math.sin(l * Math.PI / length) * 2.5 + 1);

                for (int xx = (int) (x - size); xx <= (int) (x + size); xx++) {
                    for (int yy = (int) (y - size); yy <= (int) (y + size); yy++) {
                        for (int zz = (int) (z - size); zz <= (int) (z + size); zz++) {
                            float xd = xx - x;
                            float yd = yy - y;
                            float zd = zz - z;
                            float dd = xd * xd + (yd * yd) * 2 + zd * zd;
                            if (dd < size * size && xx >= 1 && yy >= 1 && zz >= 1 && xx < width - 1 && yy < depth - 1 && zz < height - 1) {
                                int ii = (yy * height + zz) * width + xx;
                                if (blocks[ii] == Tile.rock.id) {
                                    blocks[ii] = 0;
                                }
                            }
                        }
                    }
                }
            }
        }
        return blocks;
    }

    public void addWater() {
        long before = System.nanoTime();
        long tiles = 0L;
        int source = 0;
        int target = Tile.calmWater.id;
        this.loading(0);

        for(int x = 0; x < this.width; ++x) {
            tiles += this.floodFillLiquid(x, this.depth / 2 - 1, 0, source, target);
            tiles += this.floodFillLiquid(x, this.depth / 2 - 1, this.height - 1, source, target);
        }

        for(int y = 0; y < this.height; ++y) {
            tiles += this.floodFillLiquid(0, this.depth / 2 - 1, y, source, target);
            tiles += this.floodFillLiquid(this.width - 1, this.depth / 2 - 1, y, source, target);
        }

        int count = this.width * this.height / 5000;

        for(int i = 0; i < count; ++i) {
            if (i % 100 == 0) {
                this.loading(i * 100 / (count - 1));
            }
            int x = this.random.nextInt(this.width);
            int y = this.depth / 2 - 1;
            int z = this.random.nextInt(this.height);
            if (this.blocks[(y * this.height + z) * this.width + x] == 0) {
                tiles += this.floodFillLiquid(x, y, z, 0, target);
            }
        }

        long after = System.nanoTime();
        System.out.println("Flood filled " + tiles + " tiles in " + (double)(after - before) / (double)1000000.0F + " ms");
    }

    public void addLava() {
        int lavaCount = 0;

        for(int i = 0; i < this.width * this.height * this.depth / 10000; ++i) {
            int x = this.random.nextInt(this.width);
            int y = this.random.nextInt(this.depth / 2);
            int z = this.random.nextInt(this.height);
            if (this.blocks[(y * this.height + z) * this.width + x] == 0) {
                ++lavaCount;
                this.floodFillLiquid(x, y, z, 0, Tile.calmLava.id);
            }
        }

        System.out.println("LavaCount: " + lavaCount);
    }

    private void loading(int value) {
        this.levelLoaderListener.levelLoading(value);
    }

    public long floodFillLiquid(int x, int y, int z, int source, int tt) {
        byte target = (byte)tt;
        ArrayList<int[]> coordBuffer = new ArrayList();
        int p = 0;
        int wBits = 1;

        int hBits;
        for(hBits = 1; 1 << wBits < this.width; ++wBits) {
        }

        while(1 << hBits < this.height) {
            ++hBits;
        }

        int hMask = this.height - 1;
        int wMask = this.width - 1;
        this.coords[p++] = ((y << hBits) + z << wBits) + x;
        long tiles = 0L;
        int upStep = this.width * this.height;

        while(p > 0) {
            --p;
            int cl = this.coords[p];
            if (p == 0 && coordBuffer.size() > 0) {
                System.out.println("IT HAPPENED!");
                this.coords = (int[])coordBuffer.remove(coordBuffer.size() - 1);
                p = this.coords.length;
            }

            int z0 = cl >> wBits & hMask;
            int y0 = cl >> wBits + hBits;
            int x0 = cl & wMask;

            int x1;
            for(x1 = x0; x0 > 0 && this.blocks[cl - 1] == source; --cl) {
                --x0;
            }

            while(x1 < this.width && this.blocks[cl + x1 - x0] == source) {
                ++x1;
            }

            int z1 = cl >> wBits & hMask;
            int y1 = cl >> wBits + hBits;
            if (z1 != z0 || y1 != y0) {
                System.out.println("hoooly fuck");
            }

            boolean lastNorth = false;
            boolean lastSouth = false;
            boolean lastBelow = false;
            tiles += (long)(x1 - x0);

            for(int xx = x0; xx < x1; ++xx) {
                this.blocks[cl] = target;
                if (z0 > 0) {
                    boolean north = this.blocks[cl - this.width] == source;
                    if (north && !lastNorth) {
                        if (p == this.coords.length) {
                            coordBuffer.add(this.coords);
                            this.coords = new int[1048576];
                            p = 0;
                        }

                        this.coords[p++] = cl - this.width;
                    }

                    lastNorth = north;
                }

                if (z0 < this.height - 1) {
                    boolean south = this.blocks[cl + this.width] == source;
                    if (south && !lastSouth) {
                        if (p == this.coords.length) {
                            coordBuffer.add(this.coords);
                            this.coords = new int[1048576];
                            p = 0;
                        }

                        this.coords[p++] = cl + this.width;
                    }

                    lastSouth = south;
                }

                if (y0 > 0) {
                    int belowId = this.blocks[cl - upStep];
                    if ((target == Tile.lava.id || target == Tile.calmLava.id) && (belowId == Tile.water.id || belowId == Tile.calmWater.id)) {
                        this.blocks[cl - upStep] = (byte)Tile.rock.id;
                    }

                    boolean below = belowId == source;
                    if (below && !lastBelow) {
                        if (p == this.coords.length) {
                            coordBuffer.add(this.coords);
                            this.coords = new int[1048576];
                            p = 0;
                        }

                        this.coords[p++] = cl - upStep;
                    }

                    lastBelow = below;
                }

                ++cl;
            }
        }

        return tiles;
    }
}
