//package com.mojang.minecraft.a.b;
//
//import com.mojang.minecraft.c;
//import com.mojang.minecraft.a.f;
//import com.mojang.minecraft.a.b.a.b;
//import com.mojang.minecraft.level.LevelLoaderListener;
//import com.mojang.minecraft.level.levelgen.synth.Distort;
//import com.mojang.minecraft.level.levelgen.synth.PerlinNoise;
//import com.mojang.minecraft.level.levelgen.synth.Synth;
//import com.mojang.minecraft.level.tile.Tile;
//
//import java.util.ArrayList;
//import java.util.Random;
//
//public final class Level {
//    private LevelLoaderListener levelLoaderListener;
//    private int b;
//    private int c;
//    private int d;
//    private Random e = new Random();
//    private byte[] f;
//    private int[] coords = new int[1048576];
//
//    public Level(LevelLoaderListener levelLoaderListener) {
//        this.levelLoaderListener = levelLoaderListener;
//    }
//
//    public final boolean a(Level var1, String var2, int var3, int var4, int var5) {
//        this.levelLoaderListener.beginLevelLoading("Generating level");
//        this.b = 256;
//        this.c = 256;
//        this.d = 64;
//        this.f = new byte[256 << 8 << 6];
//        this.levelLoaderListener.levelLoadUpdate("Raising..");
//        Level var27 = this;
//        Distort var8 = new Distort(new PerlinNoise(this.e, 8), new PerlinNoise(this.e, 8));
//        Distort var9 = new Distort(new PerlinNoise(this.e, 8), new PerlinNoise(this.e, 8));
//        PerlinNoise var10 = new PerlinNoise(this.e, 8);
//        int[] var11 = new int[this.b * this.c];
//
//        for(int var32 = 0; var32 < var27.b; ++var32) {
//            var27.a(var32 * 100 / (var27.b - 1));
//
//            for(int var13 = 0; var13 < var27.c; ++var13) {
//                double var14 = ((Synth)var8).getValue((double)var32, (double)var13) / (double)8.0F - (double)8.0F;
//                double var16 = ((Synth)var9).getValue((double)var32, (double)var13) / (double)8.0F + (double)8.0F;
//                if (((Synth)var10).getValue((double)var32, (double)var13) / (double)8.0F > (double)2.0F) {
//                    var16 = var14;
//                }
//
//                double var20;
//                var20 = ((var20 = Math.max(var14, var16)) * var20 * var20 / (double)100.0F + var20 * (double)3.0F) / (double)8.0F;
//                var11[var32 + var13 * var27.b] = (int)var20;
//            }
//        }
//
//        this.levelLoaderListener.levelLoadUpdate("Eroding..");
//        int[] var36 = var11;
//        var27 = this;
//        var9 = new Distort(new PerlinNoise(this.e, 8), new PerlinNoise(this.e, 8));
//        Distort var43 = new Distort(new PerlinNoise(this.e, 8), new PerlinNoise(this.e, 8));
//
//        for(int var47 = 0; var47 < var27.b; ++var47) {
//            var27.a(var47 * 100 / (var27.b - 1));
//
//            for(int var33 = 0; var33 < var27.c; ++var33) {
//                double var50 = ((Synth)var9).getValue((double)(var47 << 1), (double)(var33 << 1)) / (double)8.0F;
//                int var15 = ((Synth)var43).getValue((double)(var47 << 1), (double)(var33 << 1)) > (double)0.0F ? 1 : 0;
//                if (var50 > (double)2.0F) {
//                    int var63 = ((var36[var47 + var33 * var27.b] - var15) / 2 << 1) + var15;
//                    var36[var47 + var33 * var27.b] = var63;
//                }
//            }
//        }
//
//        this.levelLoaderListener.levelLoadUpdate("Soiling..");
//        var36 = var11;
//        var27 = this;
//        int var41 = this.b;
//        int var44 = this.c;
//        int var48 = this.d;
//
//        for(int var34 = 0; var34 < var41; ++var34) {
//            var27.a(var34 * 100 / (var27.b - 1));
//
//            for(int var51 = 0; var51 < var48; ++var51) {
//                for(int var54 = 0; var54 < var44; ++var54) {
//                    int i = (var51 * var27.c + var54) * var27.b + var34;
//                    int var64;
//                    int var17 = (var64 = var36[var34 + var54 * var41] + var48 / 2) - 2;
//                    int id = 0;
//                    if (var51 == var64 && var51 >= var48 / 2 - 1) {
//                        id = Tile.grass.id;
//                    } else if (var51 <= var64) {
//                        id = Tile.dirt.id;
//                    }
//
//                    if (var51 <= var17) {
//                        id = Tile.rock.id;
//                    }
//
//                    var27.f[i] = (byte)id;
//                }
//            }
//        }
//
//        this.levelLoaderListener.levelLoadUpdate("Carving..");
//        var27 = this;
//        int var38 = this.b;
//        var41 = this.c;
//        var44 = this.d;
//        var48 = var38 * var41 * var44 / 256 / 64;
//
//        for(int var35 = 0; var35 < var48; ++var35) {
//            var27.a(var35 * 100 / (var48 - 1));
//            float var52 = var27.e.nextFloat() * (float)var38;
//            float var55 = var27.e.nextFloat() * (float)var44;
//            float var60 = var27.e.nextFloat() * (float)var41;
//            int var65 = (int)(var27.e.nextFloat() + var27.e.nextFloat() * 150.0F);
//            float var67 = (float)((double)var27.e.nextFloat() * Math.PI * (double)2.0F);
//            float var69 = 0.0F;
//            float var19 = (float)((double)var27.e.nextFloat() * Math.PI * (double)2.0F);
//            float var73 = 0.0F;
//
//            for(int var21 = 0; var21 < var65; ++var21) {
//                var52 = (float)((double)var52 + Math.sin((double)var67) * Math.cos((double)var19));
//                var60 = (float)((double)var60 + Math.cos((double)var67) * Math.cos((double)var19));
//                var55 = (float)((double)var55 + Math.sin((double)var19));
//                var67 += var69 * 0.2F;
//                float var70;
//                var69 = (var70 = var69 * 0.9F) + (var27.e.nextFloat() - var27.e.nextFloat());
//                var19 = (var19 + var73 * 0.5F) * 0.5F;
//                float var74;
//                var73 = (var74 = var73 * 0.9F) + (var27.e.nextFloat() - var27.e.nextFloat());
//                float var26 = (float)(Math.sin((double)var21 * Math.PI / (double)var65) * (double)2.5F + (double)1.0F);
//
//                for(int var6 = (int)(var52 - var26); var6 <= (int)(var52 + var26); ++var6) {
//                    for(int var7 = (int)(var55 - var26); var7 <= (int)(var55 + var26); ++var7) {
//                        for(int var12 = (int)(var60 - var26); var12 <= (int)(var60 + var26); ++var12) {
//                            float var22 = (float)var6 - var52;
//                            float var23 = (float)var7 - var55;
//                            float var24 = (float)var12 - var60;
//                            if (var22 * var22 + var23 * var23 * 2.0F + var24 * var24 < var26 * var26 && var6 >= 1 && var7 >= 1 && var12 >= 1 && var6 < var27.b - 1 && var7 < var27.d - 1 && var12 < var27.c - 1) {
//                                int var75 = (var7 * var27.c + var12) * var27.b + var6;
//                                if (var27.f[var75] == com.mojang.minecraft.a.a.a.c.l) {
//                                    var27.f[var75] = 0;
//                                }
//                            }
//                        }
//                    }
//                }
//            }
//        }
//
//        this.levelLoaderListener.levelLoadUpdate("Watering..");
//        var27 = this;
//        long var39 = System.nanoTime();
//        long var46 = 0L;
//        int var53 = com.mojang.minecraft.a.a.a.h.l;
//        this.a(0);
//
//        for(int var56 = 0; var56 < var27.b; ++var56) {
//            var46 = var46 + var27.a(var56, var27.d / 2 - 1, 0, 0, var53) + var27.a(var56, var27.d / 2 - 1, var27.c - 1, 0, var53);
//        }
//
//        for(int var57 = 0; var57 < var27.c; ++var57) {
//            var46 = var46 + var27.a(0, var27.d / 2 - 1, var57, 0, var53) + var27.a(var27.b - 1, var27.d / 2 - 1, var57, 0, var53);
//        }
//
//        int var58 = var27.b * var27.c / 200;
//
//        for(int var61 = 0; var61 < var58; ++var61) {
//            if (var61 % 100 == 0) {
//                var27.a(var61 * 100 / (var58 - 1));
//            }
//
//            int var66 = var27.e.nextInt(var27.b);
//            int var68 = var27.d / 2 - 1 - var27.e.nextInt(3);
//            int var71 = var27.e.nextInt(var27.c);
//            if (var27.f[(var68 * var27.c + var71) * var27.b + var66] == 0) {
//                var46 += var27.a(var66, var68, var71, 0, var53);
//            }
//        }
//
//        var27.a(100);
//        long var62 = System.nanoTime();
//        System.out.println("Flood filled " + var46 + " tiles in " + (double)(var62 - var39) / (double)1000000.0F + " ms");
//        this.levelLoaderListener.levelLoadUpdate("Melting..");
//        this.a();
//        var1.a(256, 64, 256, this.f);
//        var1.j = System.currentTimeMillis();
//        var1.i = var2;
//        var1.h = "A Nice World";
//        return true;
//    }
//
//    private void a(int var1) {
//        this.a.a(var1);
//    }
//
//    private void a() {
//        int var1 = 0;
//        int var2 = this.b * this.c * this.d / 10000;
//
//        for(int var3 = 0; var3 < var2; ++var3) {
//            if (var3 % 100 == 0) {
//                this.a(var3 * 100 / (var2 - 1));
//            }
//
//            int var4 = this.e.nextInt(this.b);
//            int var5 = this.e.nextInt(this.d / 2 - 4);
//            int var6 = this.e.nextInt(this.c);
//            if (this.f[(var5 * this.c + var6) * this.b + var4] == 0) {
//                ++var1;
//                this.a(var4, var5, var6, 0, com.mojang.minecraft.a.a.a.j.l);
//            }
//        }
//
//        this.a(100);
//        System.out.println("LavaCount: " + var1);
//    }
//
//    private long a(int var1, int var2, int var3, int var4, int var5) {
//        var4 = (byte)var5;
//        ArrayList var24 = new ArrayList();
//        int var6 = 0;
//        int var7 = 1;
//
//        int var8;
//        for(var8 = 1; 1 << var7 < this.b; ++var7) {
//        }
//
//        while(1 << var8 < this.c) {
//            ++var8;
//        }
//
//        int var9 = this.c - 1;
//        int var10 = this.b - 1;
//        ++var6;
//        this.coords[0] = ((var2 << var8) + var3 << var7) + var1;
//        long var13 = 0L;
//        var1 = this.b * this.c;
//
//        while(var6 > 0) {
//            --var6;
//            var2 = this.coords[var6];
//            if (var6 == 0 && var24.size() > 0) {
//                System.out.println("IT HAPPENED!");
//                this.coords = (int[])var24.remove(var24.size() - 1);
//                var6 = this.coords.length;
//            }
//
//            var3 = var2 >> var7 & var9;
//            int var11 = var2 >> var7 + var8;
//
//            int var12;
//            int var15;
//            for(var15 = var12 = var2 & var10; var12 > 0 && this.f[var2 - 1] == 0; --var2) {
//                --var12;
//            }
//
//            while(var15 < this.b && this.f[var2 + var15 - var12] == 0) {
//                ++var15;
//            }
//
//            int var16 = var2 >> var7 & var9;
//            int var17 = var2 >> var7 + var8;
//            if (var16 != var3 || var17 != var11) {
//                System.out.println("hoooly fuck");
//            }
//
//            var16 = 0;
//            var17 = 0;
//            boolean var18 = false;
//            var13 += (long)(var15 - var12);
//
//            for(int var26 = var12; var26 < var15; ++var26) {
//                this.f[var2] = (byte)var4;
//                if (var3 > 0) {
//                    boolean var19;
//                    if ((var19 = this.f[var2 - this.b] == 0) && !var16) {
//                        if (var6 == this.coords.length) {
//                            var24.add(this.coords);
//                            this.coords = new int[1048576];
//                            var6 = 0;
//                        }
//
//                        this.coords[var6++] = var2 - this.b;
//                    }
//
//                    var16 = var19;
//                }
//
//                if (var3 < this.c - 1) {
//                    boolean var29;
//                    if ((var29 = this.f[var2 + this.b] == 0) && !var17) {
//                        if (var6 == this.coords.length) {
//                            var24.add(this.coords);
//                            this.coords = new int[1048576];
//                            var6 = 0;
//                        }
//
//                        this.coords[var6++] = var2 + this.b;
//                    }
//
//                    var17 = var29;
//                }
//
//                if (var11 > 0) {
//                    byte var30 = this.f[var2 - var1];
//                    if ((var4 == com.mojang.minecraft.a.a.a.i.l || var4 == com.mojang.minecraft.a.a.a.j.l) && (var30 == com.mojang.minecraft.a.a.a.g.l || var30 == com.mojang.minecraft.a.a.a.h.l)) {
//                        this.f[var2 - var1] = (byte)com.mojang.minecraft.a.a.a.c.l;
//                    }
//
//                    if ((var30 = var30 == 0) && !var18) {
//                        if (var6 == this.coords.length) {
//                            var24.add(this.coords);
//                            this.coords = new int[1048576];
//                            var6 = 0;
//                        }
//
//                        this.coords[var6++] = var2 - var1;
//                    }
//
//                    var18 = (boolean)var30;
//                }
//
//                ++var2;
//            }
//        }
//
//        return var13;
//    }
//}
