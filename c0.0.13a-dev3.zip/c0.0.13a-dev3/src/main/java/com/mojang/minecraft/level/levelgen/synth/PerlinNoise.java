package com.mojang.minecraft.level.levelgen.synth;

import java.util.Random;

public class PerlinNoise extends Synth {
    private ImprovedNoise[] noiseLevels;
    private int levels;

    public PerlinNoise(Random random, int levels) {
        this.levels = levels;
        this.noiseLevels = new ImprovedNoise[levels];

        for (int i = 0; i < levels; i++) {
            this.noiseLevels[i] = new ImprovedNoise(random);
        }
    }

    public double getValue(double x, double y) {
        double value = (double)0.0F;
        double pow = (double)1.0F;

        for (int i = 0; i < levels; i++) {
            value += this.noiseLevels[i].getValue(x / pow, y / pow) * pow;
            pow *= (double)2.0F;
        }

        return value;
    }
}
