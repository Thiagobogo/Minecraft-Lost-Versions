package com.mojang.minecraft.level.levelgen.synth;

import java.util.Random;

public class ImprovedNoise extends Synth {
    private int[] p;
    public double scale;

    public ImprovedNoise() {
        this(new Random());
    }

    public ImprovedNoise(Random random) {
        this.p = new int[512];

        for(int i = 0; i < 256; this.p[i] = i++) {
        }

        for(int i = 0; i < 256; ++i) {
            int j = random.nextInt(256 - i) + i;
            int tmp = this.p[i];
            this.p[i] = this.p[j];
            this.p[j] = tmp;
            this.p[i + 256] = this.p[i];
        }

    }

    public double noise(double x, double y, double z) {
        int X = (int)Math.floor(x) & 255;
        int Y = (int)Math.floor(y) & 255;
        int Z = (int)Math.floor(z) & 255;
        x -= Math.floor(x);
        y -= Math.floor(y);
        z -= Math.floor(z);
        double u = this.fade(x);
        double v = this.fade(y);
        double w = this.fade(z);
        int A = this.p[X] + Y;
        int AA = this.p[A] + Z;
        int AB = this.p[A + 1] + Z;
        int B = this.p[X + 1] + Y;
        int BA = this.p[B] + Z;
        int BB = this.p[B + 1] + Z;
        return this.lerp(w, this.lerp(v, this.lerp(u, this.grad(this.p[AA], x, y, z), this.grad(this.p[BA], x - (double)1.0F, y, z)), this.lerp(u, this.grad(this.p[AB], x, y - (double)1.0F, z), this.grad(this.p[BB], x - (double)1.0F, y - (double)1.0F, z))), this.lerp(v, this.lerp(u, this.grad(this.p[AA + 1], x, y, z - (double)1.0F), this.grad(this.p[BA + 1], x - (double)1.0F, y, z - (double)1.0F)), this.lerp(u, this.grad(this.p[AB + 1], x, y - (double)1.0F, z - (double)1.0F), this.grad(this.p[BB + 1], x - (double)1.0F, y - (double)1.0F, z - (double)1.0F))));
    }

    public double fade(double t) {
        return t * t * t * (t * (t * (double)6.0F - (double)15.0F) + (double)10.0F);
    }

    public double lerp(double t, double a, double b) {
        return a + t * (b - a);
    }

    public double grad(int hash, double x, double y, double z) {
        int h = hash & 15;
        double u = h < 8 ? x : y;
        double v = h < 4 ? y : (h != 12 && h != 14 ? z : x);
        return ((h & 1) == 0 ? u : -u) + ((h & 2) == 0 ? v : -v);
    }

    public double getValue(double x, double y) {
        return this.noise(x, y, (double)0.0F);
    }
}
