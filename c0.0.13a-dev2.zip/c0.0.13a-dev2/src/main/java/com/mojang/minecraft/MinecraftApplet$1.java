package com.mojang.minecraft;

import java.awt.Canvas;

class MinecraftApplet$1 extends Canvas {
    // $FF: synthetic field
    final MinecraftApplet this$0;

    MinecraftApplet$1(MinecraftApplet var1) {
        this.this$0 = var1;
    }

    public void addNotify() {
        super.addNotify();
        this.this$0.startGameThread();
    }

    public void removeNotify() {
        this.this$0.stopGameThread();
        super.removeNotify();
    }
}