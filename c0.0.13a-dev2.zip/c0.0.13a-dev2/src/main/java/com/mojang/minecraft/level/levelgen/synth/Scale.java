package com.mojang.minecraft.level.levelgen.synth;

public class Scale extends Synth {
    private Synth synth;
    private double xScale;
    private double yScale;

    public Scale(Synth synth, double xScale, double yScale) {
        this.synth = synth;
        this.xScale = (double)1.0F / xScale;
        this.yScale = (double)1.0F / yScale;
    }

    public double getValue(double x, double y) {
        return this.synth.getValue(x * this.xScale, y * this.yScale);
    }
}
