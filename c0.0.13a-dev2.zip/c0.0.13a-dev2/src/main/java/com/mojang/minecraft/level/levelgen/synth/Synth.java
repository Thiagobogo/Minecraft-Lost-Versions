package com.mojang.minecraft.level.levelgen.synth;

public abstract class Synth {
    public Synth() {}

    public abstract double getValue(double x, double y);
}
