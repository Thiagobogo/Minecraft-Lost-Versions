package com.mojang.minecraft.level;

public interface LevelLoaderListener {
    void beginLevelLoading(String var1);

    void levelLoadUpdate(String var1);

    void levelLoading(int var1);
}
