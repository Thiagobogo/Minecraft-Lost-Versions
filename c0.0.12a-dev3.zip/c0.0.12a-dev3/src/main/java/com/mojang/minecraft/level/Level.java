package com.mojang.minecraft.level;

import com.mojang.minecraft.level.tile.Tile;
import com.mojang.minecraft.phys.AABB;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Random;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class Level {
    private static final int TILE_UPDATE_INTERVAL = 200;
    public final int width;
    public final int height;
    public final int depth;
    private final boolean islandMode;
    private byte[] blocks;
    private int[] lightDepths;
    private ArrayList<LevelListener> levelListeners = new ArrayList();
    private Random random = new Random();
    private int randValue;
    int unprocessed = 0;
    private int[] coords = new int[1048576];

    public Level(int w, int h, int d, boolean i) {
        this.width = w;
        this.height = h;
        this.depth = d;
        this.islandMode = i;
        this.blocks = new byte[w * h * d];
        this.lightDepths = new int[w * h];

        if (!this.load()) {
            this.generateLevel();
        }

        this.randValue = this.random.nextInt();
    }

    public void generateLevel() {
        int w = width;
        int h = height;
        int d = depth;
        int[] heightmap1 = new NoiseMap(random, 0, islandMode).read(w, h);
        int[] heightmap2 = new NoiseMap(random, 1, islandMode).read(w, h);
        int[] cf = new NoiseMap(random, 3, false).read(w, h);
        int[] cf2 = new NoiseMap(random, 3, false).read(w, h);
        int[] rockMap = new NoiseMap(random, 1, islandMode).read(w, h);
        byte[] blocks = new byte[width * height * depth];

        int waterLevel = d / 2;

        for (int x = 0; x < w; x++) {
            for (int y = 0; y < d; y++) {
                for (int z = 0; z < h; z++) {
                    int dh1 = heightmap1[x + z * width];
                    int dh2 = heightmap2[x + z * width];
                    int cfh = cf[x + z * width];
                    int cfh2 = cf2[x + z * width];

                    if (cfh < 128) {
                        dh2 = dh1;
                    }

                    int dh = dh1;
                    if (dh2 > dh1) {
                        dh = dh2;
                    }

                    dh = (dh - 128) / 8 + waterLevel - 1;
                    int rh = ((rockMap[x + z * width] - 128) / 6 + waterLevel + dh) / 2;
                    if (cfh2 < 92) {
                        dh = dh / 2 << 1;
                    } else if (cfh2 < 160) {
                        dh = dh / 4 << 2;
                    }

                    if (dh < waterLevel - 2) {
                        dh = (dh - waterLevel) / 2 + waterLevel;
                    }

                    if (rh > dh - 2) {
                        rh = dh - 2;
                    }

                    int ii = (y * height + z) * width + x;
                    int id = 0;
                    if (y == dh && y >= d / 2) {
                        id = Tile.grass.id;
                    }

                    if (y < dh) {
                        id = Tile.dirt.id;
                    }

                    if (y <= rh) {
                        id = Tile.rock.id;
                    }

                    blocks[ii] = (byte)id;
                }
            }
        }

        int count = w * h * d / 256 / 64;
        for (int i = 0; i < count; i++) {
            float x = random.nextFloat() * w;
            float y = random.nextFloat() * d;
            float z = random.nextFloat() * h;
            int length = (int) (random.nextFloat() + random.nextFloat() * 150);
            float dir1 = (float) (random.nextFloat() * Math.PI * 2);
            float dira1 = 0;
            float dir2 = (float) (random.nextFloat() * Math.PI * 2);
            float dira2 = 0;

            for (int l = 0; l < length; l++) {
                x += Math.sin(dir1) * Math.cos(dir2);
                z += Math.cos(dir1) * Math.cos(dir2);
                y += Math.sin(dir2);

                dir1 += dira1 * 0.2f;
                dira1 *= 0.9f;
                dira1 += (random.nextFloat() - random.nextFloat());

                dir2 += dira2 * 0.5f;
                dir2 *= 0.5f;
                dira2 *= 0.9f;
                dira2 += (random.nextFloat() - random.nextFloat());

                float size = (float) (Math.sin(l * Math.PI / length) * 2.5 + 1);

                for (int xx = (int) (x - size); xx <= (int) (x + size); xx++) {
                    for (int yy = (int) (y - size); yy <= (int) (y + size); yy++) {
                        for (int zz = (int) (z - size); zz <= (int) (z + size); zz++) {
                            float xd = xx - x;
                            float yd = yy - y;
                            float zd = zz - z;
                            float dd = xd * xd + (yd * yd) * 2 + zd * zd;
                            if (dd < size * size && xx >= 1 && yy >= 1 && zz >= 1 && xx < width - 1 && yy < depth - 1 && zz < height - 1) {
                                int ii = (yy * height + zz) * width + xx;
                                if (blocks[ii] == Tile.rock.id) {
                                    blocks[ii] = 0;
                                }
                            }
                        }
                    }
                }
            }
        }

        this.blocks = blocks;

        long before = System.nanoTime();
        long tiles = 0L;
        int source = 0;
        int target = Tile.calmWater.id;

        for(int x = 0; x < this.width; ++x) {
            tiles += this.floodFillLiquid(x, this.depth / 2 - 1, 0, source, target);
            tiles += this.floodFillLiquid(x, this.depth / 2 - 1, this.height - 1, source, target);
        }

        for(int y = 0; y < this.height; ++y) {
            tiles += this.floodFillLiquid(0, this.depth / 2 - 1, y, source, target);
            tiles += this.floodFillLiquid(this.width - 1, this.depth / 2 - 1, y, source, target);
        }

        count = this.width * this.height / 5000;

        for(int i = 0; i < count; ++i) {
            int x = this.random.nextInt(this.width);
            int y = this.depth / 2 - 1;
            int z = this.random.nextInt(this.height);
            if (this.blocks[(y * this.height + z) * this.width + x] == 0) {
                tiles += this.floodFillLiquid(x, y, z, 0, target);
            }
        }

        long after = System.nanoTime();
        System.out.println("Flood filled " + tiles + " tiles in " + (double)(after - before) / (double)1000000.0F + " ms");

        int lavaCount = 0;

        for(int i = 0; i < this.width * this.height * this.depth / 10000; ++i) {
            int x = this.random.nextInt(this.width);
            int y = this.random.nextInt(this.depth / 2);
            int z = this.random.nextInt(this.height);
            if (this.blocks[(y * this.height + z) * this.width + x] == 0) {
                ++lavaCount;
                this.floodFillLiquid(x, y, z, 0, Tile.calmLava.id);
            }
        }

        System.out.println("LavaCount: " + lavaCount);

        this.calcLightDepths(0, 0, this.width, this.height);

        for (int i = 0; i < this.levelListeners.size(); ++i) {
            this.levelListeners.get(i).allChanged();
        }
    }

    public boolean load() {
        try {
            DataInputStream dis = new DataInputStream(new GZIPInputStream(new FileInputStream(new File("level.dat"))));
            dis.readFully(this.blocks);
            this.calcLightDepths(0, 0, this.width, this.height);

            for(int i = 0; i < this.levelListeners.size(); ++i) {
                ((LevelListener)this.levelListeners.get(i)).allChanged();
            }

            dis.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public void save() {
        try {
            DataOutputStream dos = new DataOutputStream(new GZIPOutputStream(new FileOutputStream(new File("level.dat"))));
            dos.write(this.blocks);
            dos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void calcLightDepths(int x0, int y0, int x1, int y1) {
        for(int x = x0; x < x0 + x1; ++x) {
            for(int z = y0; z < y0 + y1; ++z) {
                int oldDepth = this.lightDepths[x + z * this.width];

                int y;
                for(y = this.depth - 1; y > 0 && !this.isLightBlocker(x, y, z); --y) {
                }

                this.lightDepths[x + z * this.width] = y + 1;
                if (oldDepth != y) {
                    int yl0 = oldDepth < y ? oldDepth : y;
                    int yl1 = oldDepth > y ? oldDepth : y;

                    for(int i = 0; i < this.levelListeners.size(); ++i) {
                        ((LevelListener)this.levelListeners.get(i)).lightColumnChanged(x, z, yl0, yl1);
                    }
                }
            }
        }
    }

    public void addListener(LevelListener levelListener) {
        this.levelListeners.add(levelListener);
    }

    public void removeListener(LevelListener levelListener) {
        this.levelListeners.remove(levelListener);
    }

    public boolean isLightBlocker(int x, int y, int z) {
        Tile tile = Tile.tiles[this.getTile(x, y, z)];
        return tile == null ? false : tile.blocksLight();
    }

    public ArrayList<AABB> getCubes(AABB aABB) {
        ArrayList<AABB> aABBs = new ArrayList();
        int x0 = (int)Math.floor((double)aABB.x0);
        int x1 = (int)Math.floor((double)(aABB.x1 + 1.0F));
        int y0 = (int)Math.floor((double)aABB.y0);
        int y1 = (int)Math.floor((double)(aABB.y1 + 1.0F));
        int z0 = (int)Math.floor((double)aABB.z0);
        int z1 = (int)Math.floor((double)(aABB.z1 + 1.0F));

        for(int x = x0; x < x1; ++x) {
            for(int y = y0; y < y1; ++y) {
                for(int z = z0; z < z1; ++z) {
                    if (x >= 0 && y >= 0 && z >= 0 && x < this.width && y < this.depth && z < this.height) {
                        Tile tile = Tile.tiles[this.getTile(x, y, z)];
                        if (tile != null) {
                            AABB aabb = tile.getAABB(x, y, z);
                            if (aabb != null) {
                                aABBs.add(aabb);
                            }
                        }
                    } else if (x < 0 || y < 0 || z < 0 || x >= this.width || z >= this.height) {
                        AABB aabb = Tile.unbreakable.getAABB(x, y, z);
                        if (aabb != null) {
                            aABBs.add(aabb);
                        }
                    }
                }
            }
        }

        return aABBs;
    }

    public boolean setTile(int x, int y, int z, int type) {
        if (x >= 0 && y >= 0 && z >= 0 && x < this.width && y < this.depth && z < this.height) {
            if (type == this.blocks[(y * this.height + z) * this.width + x]) {
                return false;
            } else {
                this.blocks[(y * this.height + z) * this.width + x] = (byte)type;
                this.neighborChanged(x - 1, y, z, type);
                this.neighborChanged(x + 1, y, z, type);
                this.neighborChanged(x, y - 1, z, type);
                this.neighborChanged(x, y + 1, z, type);
                this.neighborChanged(x, y, z - 1, type);
                this.neighborChanged(x, y, z + 1, type);
                this.calcLightDepths(x, z, 1, 1);

                for(int i = 0; i < this.levelListeners.size(); ++i) {
                    ((LevelListener)this.levelListeners.get(i)).tileChanged(x, y, z);
                }

                return true;
            }
        } else {
            return false;
        }
    }

    public boolean setTileNoUpdate(int x, int y, int z, int type) {
        if (x >= 0 && y >= 0 && z >= 0 && x < this.width && y < this.depth && z < this.height) {
            if (type == this.blocks[(y * this.height + z) * this.width + x]) {
                return false;
            } else {
                this.blocks[(y * this.height + z) * this.width + x] = (byte)type;
                this.calcLightDepths(x, z, 1, 1);

                return true;
            }
        } else {
            return false;
        }
    }

    private void neighborChanged(int x, int y, int z, int type) {
        if (x >= 0 && y >= 0 && z >= 0 && x < this.width && y < this.depth && z < this.height) {
            Tile tile = Tile.tiles[this.blocks[(y * this.height + z) * this.width + x]];
            if (tile != null) {
                tile.neighborChanged(this, x, y, z, type);
            }
        }
    }

    public boolean isLit(int x, int y, int z) {
        if (x >= 0 && y >= 0 && z >= 0 && x < this.width && y < this.depth && z < this.height) {
            return y >= this.lightDepths[x + z * this.width];
        } else {
            return true;
        }
    }

    public int getTile(int x, int y, int z) {
        return x >= 0 && y >= 0 && z >= 0 && x < this.width && y < this.depth && z < this.height ? this.blocks[(y * this.height + z) * this.width + x] : 0;
    }

    public boolean isSolidTile(int x, int y, int z) {
        Tile tile = Tile.tiles[this.getTile(x, y, z)];
        return tile == null ? false : tile.isSolid();
    }

    public void tick() {
        this.unprocessed += this.width * this.height * this.depth;
        int ticks = this.unprocessed / 200;
        this.unprocessed -= ticks * 200;

        for(int i = 0; i < ticks; ++i) {
            this.randValue = this.randValue * 1664525 + 1013904223;
            int x = this.randValue >> 16 & this.width - 1;
            this.randValue = this.randValue * 1664525 + 1013904223;
            int y = this.randValue >> 16 & this.depth - 1;
            this.randValue = this.randValue * 1664525 + 1013904223;
            int z = this.randValue >> 16 & this.height - 1;
            byte id = this.blocks[(y * this.height + z) * this.width + x];
            if (Tile.shouldTick[id]) {
                Tile.tiles[id].tick(this, x, y, z, this.random);
            }
        }
    }

    public boolean containsLiquid(AABB box, int liquidId) {
        int x0 = (int)Math.floor((double)box.x0);
        int x1 = (int)Math.floor((double)(box.x1 + 1.0F));
        int y0 = (int)Math.floor((double)box.y0);
        int y1 = (int)Math.floor((double)(box.y1 + 1.0F));
        int z0 = (int)Math.floor((double)box.z0);
        int z1 = (int)Math.floor((double)(box.z1 + 1.0F));
        if (x0 < 0) {
            x0 = 0;
        }

        if (y0 < 0) {
            y0 = 0;
        }

        if (z0 < 0) {
            z0 = 0;
        }

        if (x1 > this.width) {
            x1 = this.width;
        }

        if (y1 > this.depth) {
            y1 = this.depth;
        }

        if (z1 > this.height) {
            z1 = this.height;
        }

        for(int x = x0; x < x1; ++x) {
            for(int y = y0; y < y1; ++y) {
                for(int z = z0; z < z1; ++z) {
                    Tile tile = Tile.tiles[this.getTile(x, y, z)];
                    if (tile != null && tile.getLiquidType() == liquidId) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public long floodFillLiquid(int x, int y, int z, int source, int tt) {
        byte target = (byte)tt;
        ArrayList<int[]> coordBuffer = new ArrayList();
        int p = 0;
        int wBits = 1;

        int hBits;
        for(hBits = 1; 1 << wBits < this.width; ++wBits) {
        }

        while(1 << hBits < this.height) {
            ++hBits;
        }

        int hMask = this.height - 1;
        int wMask = this.width - 1;
        this.coords[p++] = ((y << hBits) + z << wBits) + x;
        long tiles = 0L;
        int upStep = this.width * this.height;

        while(p > 0) {
            --p;
            int cl = this.coords[p];
            if (p == 0 && coordBuffer.size() > 0) {
                System.out.println("IT HAPPENED!");
                this.coords = (int[])coordBuffer.remove(coordBuffer.size() - 1);
                p = this.coords.length;
            }

            int z0 = cl >> wBits & hMask;
            int y0 = cl >> wBits + hBits;
            int x0 = cl & wMask;

            int x1;
            for(x1 = x0; x0 > 0 && this.blocks[cl - 1] == source; --cl) {
                --x0;
            }

            while(x1 < this.width && this.blocks[cl + x1 - x0] == source) {
                ++x1;
            }

            int z1 = cl >> wBits & hMask;
            int y1 = cl >> wBits + hBits;
            if (z1 != z0 || y1 != y0) {
                System.out.println("hoooly fuck");
            }

            boolean lastNorth = false;
            boolean lastSouth = false;
            boolean lastBelow = false;
            tiles += (long)(x1 - x0);

            for(int xx = x0; xx < x1; ++xx) {
                this.blocks[cl] = target;
                if (z0 > 0) {
                    boolean north = this.blocks[cl - this.width] == source;
                    if (north && !lastNorth) {
                        if (p == this.coords.length) {
                            coordBuffer.add(this.coords);
                            this.coords = new int[1048576];
                            p = 0;
                        }

                        this.coords[p++] = cl - this.width;
                    }

                    lastNorth = north;
                }

                if (z0 < this.height - 1) {
                    boolean south = this.blocks[cl + this.width] == source;
                    if (south && !lastSouth) {
                        if (p == this.coords.length) {
                            coordBuffer.add(this.coords);
                            this.coords = new int[1048576];
                            p = 0;
                        }

                        this.coords[p++] = cl + this.width;
                    }

                    lastSouth = south;
                }

                if (y0 > 0) {
                    int belowId = this.blocks[cl - upStep];
                    if ((target == Tile.lava.id || target == Tile.calmLava.id) && (belowId == Tile.water.id || belowId == Tile.calmWater.id)) {
                        this.blocks[cl - upStep] = (byte)Tile.rock.id;
                    }

                    boolean below = belowId == source;
                    if (below && !lastBelow) {
                        if (p == this.coords.length) {
                            coordBuffer.add(this.coords);
                            this.coords = new int[1048576];
                            p = 0;
                        }

                        this.coords[p++] = cl - upStep;
                    }

                    lastBelow = below;
                }

                ++cl;
            }
        }

        return tiles;
    }
}
