package com.mojang.minecraft.level.tile;

public class DirtTile extends Tile {
    protected DirtTile(int id, int tex) {
        super(id, tex);
    }
}
