package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.phys.AABB;
import com.mojang.minecraft.renderer.Tesselator;

import java.util.Random;

public class LiquidTile extends Tile {

    protected final int liquidType;
    protected int calmTileId;
    protected int tileId;
    protected int spreadSpeed = 1;

    protected LiquidTile(int id, int liquidType) {
        super(id);
        this.liquidType = liquidType;
        this.tex = 14;
        if (liquidType == 2) {
            this.tex = 30;
        }

        if (liquidType == 1) {
            this.spreadSpeed = 8;
        }

        if (liquidType == 2) {
            this.spreadSpeed = 2;
        }

        this.tileId = id + 0;
        this.calmTileId = id + 1;
        float dd = 0.1F;
        this.setShape(0.0F, 0.0F - dd, 0.0F, 1.0F, 1.0F - dd, 1.0F);
        this.setTicking(true);
    }

    public void tick(Level level, int x, int y, int z, Random random) {
        this.updateLiquid(level, x, y, z, 0);
    }

    private boolean updateLiquid(Level level, int x, int y, int z, int width) {
        boolean hasChanged = false;
        do {
            y--;

            if (level.getTile(x, y, z) != 0) {
                break;
            }

            hasChanged = level.setTile(x, y, z, this.tileId);
        } while (hasChanged);

        y++;

        if (!hasChanged) {
            hasChanged |= this.checkLiquid(level, x - 1, y, z, width);
            hasChanged |= this.checkLiquid(level, x + 1, y, z, width);
            hasChanged |= this.checkLiquid(level, x, y, z - 1, width);
            hasChanged |= this.checkLiquid(level, x, y, z + 1, width);
        }

        if (!hasChanged) {
            level.setTileNoUpdate(x, y, z, this.calmTileId);
        }

        return hasChanged;
    }

    private boolean checkLiquid(Level level, int x, int y, int z, int width) {
        boolean hasChanged = false;

        if (level.getTile(x, y, z) == 0) {
            hasChanged = level.setTile(x, y, z, this.tileId);
            if (hasChanged && width < this.spreadSpeed) {
                hasChanged |= this.updateLiquid(level, x, y, z, width + 1);
            }
        }
        return hasChanged;
    }

    protected boolean shouldRenderFace(Level level, int x, int y, int z, int layer) {
        if (x >= 0 && y >= 0 && z >= 0 && x < level.width && z < level.height) {
            if (layer != 2) {
                return false;
            } else {
                int id = level.getTile(x, y, z);
                return id != this.tileId && id != this.calmTileId ? super.shouldRenderFace(level, x, y, z, -1) : false;
            }
        } else {
            return false;
        }
    }

    public void renderFace(Tesselator t, int x, int y, int z, int face) {
        super.renderFace(t, x, y, z, face);
        super.renderBackFace(t, x, y, z, face);
    }

    public boolean mayPick() {
        return false;
    }

    public AABB getAABB(int x, int y, int z) {
        return null;
    }

    public boolean blocksLight() {
        return true;
    }

    public boolean isSolid() {
        return false;
    }

    public int getLiquidType() {
        return this.liquidType;
    }

    public void neighborChanged(Level level, int x, int y, int z, int type) {
        if (this.liquidType == 1 && (type == Tile.lava.id || type == Tile.calmLava.id)) {
            level.setTileNoUpdate(x, y, z, Tile.rock.id);
        }

        if (this.liquidType == 2 && (type == Tile.water.id || type == Tile.calmWater.id)) {
            level.setTileNoUpdate(x, y, z, Tile.rock.id);
        }
    }
}
