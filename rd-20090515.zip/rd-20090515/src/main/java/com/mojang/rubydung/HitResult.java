package com.mojang.rubydung;

public class HitResult {
    public int x;
    public int y;
    public int z;
    public int o;
    public int f;

    public HitResult(int x, int y, int z, int o, int f) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.o = o;
        this.f = f;
    }
}
