package com.mojang.minecraft;

import java.applet.Applet;

public class MinecraftApplet extends Applet {
    public MinecraftApplet() {
    }
}
